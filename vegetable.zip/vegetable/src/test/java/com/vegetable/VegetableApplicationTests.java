package com.vegetable;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VegetableApplicationTests {

	@Test
	void contextLoads() {
	}

}
