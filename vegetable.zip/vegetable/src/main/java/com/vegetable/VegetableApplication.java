package com.vegetable;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VegetableApplication {

	public static void main(String[] args) {
		SpringApplication.run(VegetableApplication.class, args);
	}

}
