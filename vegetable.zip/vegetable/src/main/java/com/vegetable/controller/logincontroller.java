package com.vegetable.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.vegetable.demo.Login;
import com.vegetable.service.loginservice;

@RestController
public class logincontroller {
	@Autowired
	loginservice ls;
	@GetMapping("/get")
	public List<Login> get()
	{
		return ls.read();
	}
	@PostMapping("/pst")
	public  String login(@RequestBody Map<String,String>data)
	{
		String userEmail=data.get("email");
		String userPassword=data.get("password");
		return ls.login(userEmail,userPassword);
	}
	@PostMapping("/adduser")
	public Login addUser(@RequestBody Login data)
	{
		return ls.adduser(data);
	}
}