package com.vegetable.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.vegetable.demo.model;
import com.vegetable.service.modelservice;

@RestController
public class modelcontroller {
	@Autowired
	modelservice ms;
	@GetMapping("/mdl")
	public List<model> get()
	{
		return ms.read();
	}
	@PostMapping("/putData")
	public model putData(@RequestBody model data)
	{
		return ms.putData(data);
	}
//sorting	
	@GetMapping("/sortDataAsc/{field}")
	public List<model> sortDataByAsc(@PathVariable("field") String data)
	{
		return ms.sortDataByAsc(data);
	}
	@GetMapping("/sortDataDesc/{field}")
	public List<model> sortDataByDesc(@PathVariable("field") String data)
	{
		return ms.sortDataByDesc(data);
	}
//paging
	@GetMapping("/pageData/{offset}/{noofrecords}")
	public Page<model> pageData(@PathVariable("offset") int pageNo,@PathVariable("noofrecords") int noOfRecords)
	{
		return ms.pageData(pageNo,noOfRecords);
	}
	@GetMapping("/pageListData/{offset}/{noofrecords}")
	public List<model> pageListData(@PathVariable("offset") int pageNo,@PathVariable("noofrecords") int noOfRecords)
	{
		return ms.pageListData(pageNo,noOfRecords);
	}
//paging and sorting	
	@GetMapping("/pageListDataAsc/{offset}/{noofrecords}/{field}")
	public List<model> pageListDataAsc(@PathVariable("offset") int pageNo,@PathVariable("noofrecords") int noOfRecords,@PathVariable("field") String data)
	{
		return ms.pageListDataAsc(pageNo,noOfRecords,data);
	}
	@GetMapping("/pageListDataDesc/{offset}/{noofrecords}/{field}")
	public List<model> pageListDataDesc(@PathVariable("offset") int pageNo,@PathVariable("noofrecords") int noOfRecords,@PathVariable("field") String data)
	{
		return ms.pageListDataDesc(pageNo,noOfRecords,data);
	}
	
}