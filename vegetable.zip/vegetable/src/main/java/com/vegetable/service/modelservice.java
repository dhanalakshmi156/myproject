package com.vegetable.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;
import com.vegetable.demo.model;
import com.vegetable.repository.modelrepo;

@Service

public class modelservice {
	@Autowired
	modelrepo mr;

	public List<model> read() {
		return mr.findAll();
	}
	public List<model> getData() {
		return mr.findAll();
	}

	public model putData(model data) {
		return mr.save(data);
	}

	public List<model> sortDataByAsc(String field) {
		return mr.findAll(Sort.by(field));
	}
	public List<model> sortDataByDesc(String field) {
		return mr.findAll(Sort.by(Direction.DESC,field));
	}

	public Page<model> pageData(int pageNo, int noOfRecords) {
		Pageable data=PageRequest.of(pageNo, noOfRecords);
		Page<model> pData=mr.findAll(data);
		return pData;
	}
	
	public List<model> pageListData(int pageNo, int noOfRecords) {
		Pageable data=PageRequest.of(pageNo, noOfRecords);
		Page<model> pData=mr.findAll(data);
		return pData.getContent();
	}
	public List<model> pageListDataAsc(int pageNo, int noOfRecords,String field) {
		Pageable data=PageRequest.of(pageNo, noOfRecords).withSort(Sort.by(field));
		Page<model> pData=mr.findAll(data);
		return pData.getContent();
	}
	public List<model> pageListDataDesc(int pageNo, int noOfRecords,String field) {
		Pageable data=PageRequest.of(pageNo, noOfRecords).withSort(Sort.by(Direction.DESC,field));
		Page<model> pData=mr.findAll(data);
		return pData.getContent();
	}
}