package com.vegetable.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vegetable.demo.Login;
import com.vegetable.repository.loginrepo;

@Service

public class loginservice {
	@Autowired
	loginrepo lr;

	public List<Login> read() {
		return lr.findAll();
	}

	public String login(String email, String password) 
	{
		try
		{
			Login userEmail=lr.findById(email).get();
			if(userEmail==null)
			{
				return"Account isn't found or email incorrect";
			}
			else
			{
				if(userEmail.getPassword().equals(password))
				{
					return "Login Successfull";
				}
				else
				{
					return "Login Unsuccessfull! Check email and password";
				}
			}
		}
		catch(Exception e)
		{
			return "Login Unsuccessfull! Check email and password";
		}
	}

	public Login adduser(Login data) {
		return lr.save(data);
	}
}