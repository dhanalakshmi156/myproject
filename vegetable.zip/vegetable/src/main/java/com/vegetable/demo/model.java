package com.vegetable.demo;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="VEGETABLES")
public class model {
	@Id
	private String email;
	private String password;
	private String name;
	private String state;
	private String country;
	private String district;
	private String vegetablename;
	private String fruitname;
	private String cost;
	public model() {
		super();
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getDistrict() {
		return district;
	}
	public void setDistrict(String district) {
		this.district = district;
	}
	public String getVegetablename() {
		return vegetablename;
	}
	public void setVegetablename(String vegetablename) {
		this.vegetablename = vegetablename;
	}
	public String getFruitname() {
		return fruitname;
	}
	public void setFruitname(String fruitname) {
		this.fruitname = fruitname;
	}
	public String getCost() {
		return cost;
	}
	public void setCost(String cost) {
		this.cost = cost;
	}
	@Override
	public String toString() {
		return "model [email=" + email + ", password=" + password + ", name=" + name + ", state=" + state + ", country="
				+ country + ", district=" + district + ", vegetablename=" + vegetablename + ", fruitname=" + fruitname
				+ ", cost=" + cost + "]";
	}
	
}