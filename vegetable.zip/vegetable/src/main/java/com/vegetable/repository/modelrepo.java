package com.vegetable.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.vegetable.demo.model;

public interface modelrepo extends JpaRepository<model,String>{

}