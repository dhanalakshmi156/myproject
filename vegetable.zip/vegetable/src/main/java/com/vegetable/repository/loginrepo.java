package com.vegetable.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.vegetable.demo.Login;

public interface loginrepo extends JpaRepository<Login, String> {

}