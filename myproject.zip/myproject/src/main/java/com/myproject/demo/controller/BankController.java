package com.myproject.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.myproject.demo.model.Bank;
import com.myproject.demo.service.BankService;

@RestController
public class BankController {
	@Autowired
	BankService holderService;
	
	@GetMapping(value="/fet")
	public List<Bank>getAllBankinfo()
	{
		List<Bank> holderList=holderService.getAllBankinfo();
		return holderList;
	}
	@PostMapping(value="/Bkinfo")
	public Bank saveBankinfo(@RequestBody Bank s) 
	{
		return holderService.saveBankinfo1(s);
	}
	
	@PutMapping(value="/upd")
	public Bank updateBankinfo(@RequestBody Bank s)
	{
		return holderService.saveBankinfo(s);
	}
	@DeleteMapping("/del/{branchno}")
	public void deleteBank(@PathVariable("branchno") int branchno)
	{
		 holderService.deleteBank(branchno);
	}
//	@GetMapping(value="/getBkinfo/{branchno}")
//	public Bank getBankinfo(@PathVariable("branchno") int branchno)
//	{
//		return holderService.findByBranchno(branchno);
//	}
}