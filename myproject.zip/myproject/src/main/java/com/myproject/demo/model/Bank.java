package com.myproject.demo.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Bank {

	@Id
	private int branchno;
	private String branchname;
	private String holdername;
	private Long accountno;
	private Long ifsccode;
	private Long mobileno;
	public int getBranchno() {
		return branchno;
	}
	public void setBranchno(int branchno) {
		this.branchno = branchno;
	}
	public String getBranchname() {
		return branchname;
	}
	public void setBranchname(String branchname) {
		this.branchname = branchname;
	}
	public String getHoldername() {
		return holdername;
	}
	public void setholdername(String holdername) {
		this.holdername = holdername;
	}
	public Long getAccountno() {
		return accountno;
	}
	public void setAccountno(Long accountno) {
		this.accountno = accountno;
	}
	public Long getIfsccode() {
		return (long) ifsccode;
	}
	public void setIfsccode(Long ifsccode) {
		this.ifsccode = ifsccode;
	}
	public Long getMobileno() {
		return mobileno;
	}
	public void setMobileno(Long mobileno) {
		this.mobileno = mobileno;
	}
	@Override
	public String toString() {
		return "Bank [branchno=" + branchno + ", branchname=" + branchname + ", holdername=" + holdername
				+ ", accountno=" + accountno + ", ifsccode=" + ifsccode + ", mobileno=" + mobileno + "]";
	}
	
}