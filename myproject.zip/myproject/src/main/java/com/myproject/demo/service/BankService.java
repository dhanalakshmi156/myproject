package com.myproject.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.myproject.demo.model.Bank;
import com.myproject.demo.repository.BankRepo;

@Service
public class BankService {
	@Autowired
	BankRepo BankRepository;
	
	public List<Bank> getAllBankinfo()
	{
		List<Bank> studList=BankRepository.findAll();
		return studList;
	}
	
	public Bank saveBankinfo1 (Bank s)
	{
		return BankRepository.save(s);
	}
	public Bank saveBankinfo (Bank k)
	{
		return BankRepository.save(k);
	}

	public String deleteBank(int branchno)
	{
		BankRepository.deleteById(branchno);
		return branchno+"deleted !!";
	}
//	public Bank getStudent(int branchno) {
//		return BankRepository.findById(branchno).get();
//	}
}