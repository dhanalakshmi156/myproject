package com.myproject.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;


import com.myproject.demo.model.Bank;

public interface BankRepo extends JpaRepository<Bank,Integer>{

}