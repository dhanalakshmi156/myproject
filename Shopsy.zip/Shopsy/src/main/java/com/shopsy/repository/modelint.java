package com.shopsy.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
//import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.shopsy.model.Model;


@Repository
public interface modelint extends JpaRepository<Model, Integer> {
	

	public List<Model> getDetailByCost(String field);


	public List<Model> findByNameStartingWith(String field);


	public List<Model> findByNameEndingWith(String field);

	@Query(value="select * from model m where m.name=:name and m.cost=:cost" ,nativeQuery = true)
	public List<Model> getDataByQuery(String name, int cost);

	@Modifying
	@Query("delete from Model m where m.name=?1")
	public int deleteBy(String name);
	

	@Modifying
	@Query("update Model m set m.name=?1,m.productNo=?2 where m.productColour=?3")
	public int updateBy(String a, String b, String c);

}
