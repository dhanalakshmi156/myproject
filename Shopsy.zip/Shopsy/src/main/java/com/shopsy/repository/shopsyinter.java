package com.shopsy.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.shopsy.model.ShopsyModel;
@Repository
public interface shopsyinter extends JpaRepository<ShopsyModel, Integer> {

}
