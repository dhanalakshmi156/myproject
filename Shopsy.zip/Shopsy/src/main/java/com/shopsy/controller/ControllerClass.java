package com.shopsy.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.shopsy.model.Model;
import com.shopsy.service.ServiceClass;

import io.swagger.v3.oas.annotations.parameters.RequestBody;

@RestController
public class ControllerClass {
	@Autowired
	ServiceClass Sc;
	@GetMapping("/get")
	public List<Model>get()
	{
		return Sc.getAllDetails();
	}
	@GetMapping("/getby/{field}")
	public List<Model> getQuery(@PathVariable String field)
	{
		return Sc.getByQuery(field);
	}
	@GetMapping("/start")
	public List<Model> start(@RequestParam String field)
	{
		return Sc.startWith(field);
	}
	@PostMapping("/post")
	public Model post(@RequestBody Model m)
	{
		return Sc.create(m);
	}
	@GetMapping("/end")
	public List<Model> end(@RequestParam String field)
	{
		return Sc.endWith(field);
	}
	@GetMapping("/query")
	public List<Model> getByQuery(@RequestParam String name,@RequestParam int cost)
	{
		return Sc.getByQuery(name,cost);
	}
	@DeleteMapping("/deleteDataQuery")
	public String deleteDataQuery(@RequestParam String name)
	{
		int result = Sc.deleteDataQuery(name);
		if(result>0)
		{
			return "Record is deleted";
		}
		else 
		{
			return "Problem occured while deleting or no records found";
		}
	}
	@PutMapping("/update")
	public int updatepro(@RequestParam String a,@RequestParam String b,@RequestParam String c)
	{
		return Sc.updateShop(a,b,c);
	}
}
