package com.shopsy.model;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;

@Entity
public class ShopsyModel {
	@Id
	private int id;
	private String address;
	private int mobileNo;
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="details")
	@Override
	public String toString() {
		return "Shopsy [id=" + id + ", address=" + address + ", mobileNo=" + mobileNo + "]";
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public int getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(int mobileNo) {
		this.mobileNo = mobileNo;
	}

}
