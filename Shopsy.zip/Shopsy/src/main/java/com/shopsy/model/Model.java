package com.shopsy.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Model {
	@Id
	private int id;
	@Column(name="Name")
	private String name;
	private String productName;
	private int productNo;
	private int noOfProducts;
	private int cost;
	private float discount;
	private String productColour;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public int getProductNo() {
		return productNo;
	}
	public void setProductNo(int productNo) {
		this.productNo = productNo;
	}
	public int getNoOfProducts() {
		return noOfProducts;
	}
	public void setNoOfProducts(int noOfProducts) {
		this.noOfProducts = noOfProducts;
	}
	public int getCost() {
		return cost;
	}
	public void setCost(int cost) {
		this.cost = cost;
	}
	public float getDiscount() {
		return discount;
	}
	public void setDiscount(float discount) {
		this.discount = discount;
	}
	public String getProductColour() {
		return productColour;
	}
	public void setProductColour(String productColour) {
		this.productColour = productColour;
	}
	@Override
	public String toString() {
		return "Model [id=" + id + ", name=" + name + ", productName=" + productName + ", productNo=" + productNo
				+ ", noOfProducts=" + noOfProducts + ", cost=" + cost + ", discount=" + discount + ", productColour="
				+ productColour + "]";
	
	}
}
