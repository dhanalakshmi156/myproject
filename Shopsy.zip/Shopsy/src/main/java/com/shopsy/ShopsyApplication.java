package com.shopsy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShopsyApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShopsyApplication.class, args);
	}

}
