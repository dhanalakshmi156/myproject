package com.shopsy.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shopsy.model.Model;
import com.shopsy.repository.modelint;
import com.shopsy.repository.shopsyinter;

import jakarta.transaction.Transactional;

@Service
public class ServiceClass {
	@Autowired
	modelint ml;

	@Autowired
	shopsyinter sr;
	
	public List<Model> getAllDetails() {
		return ml.findAll();
	}

	public List<Model> getByQuery(String field) {
		return ml.getDetailByCost(field);
	}

	public List<Model> startWith(String field) {
		return ml.findByNameStartingWith(field);
	}

	public List<Model> endWith(String field) {
		return ml.findByNameEndingWith(field);
	}

	public List<Model> getByQuery(String name, int cost) {
		return ml.getDataByQuery(name,cost);
	}
	@Transactional
	public int deleteDataQuery(String name) {
		return ml.deleteBy(name);
	}
	@Transactional
	public int updateShop(String a, String b, String c) {
		return ml.updateBy(a,b,c);
	}
		public Model create(Model m) {
			return ml.save(m);

	}
}
